#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


df=pd.read_json("E:/Data Science/FlipRobo/Assignments/NLP Sept project/Cell_Phones_and_Accessories.json")
df.head()


# In[3]:


df.shape

## The dataset has 760450 rows and 11 columns


# In[4]:


df.dtypes


# In[5]:


"""
# Data Description
1. IC - Item Code of the product
2. Rating - Rating given to the product by the customer
3. Rev_verify - Flat to represent whether the review has been verified or not
4. Review_date - Date when the review has been posted
5. Prod_meta - A dictionary of the product metadata. It contains only the addiitional information about the product, if any available.
6. Reviewer_Name - Name of the reviewer
7. Review - Text of the review
8. Rev-Summ - Summary of the review
9. Review_timestamp - time when the review has been posted (unix time format)
10. Useful - Number of useful votes (upvotes) of the review
11. Prod_image - images that users post after they have received the product

"""


# In[6]:


# Checking the missing values in the dataset
df.isnull().sum()


# In[7]:


import matplotlib.pyplot as plt
import seaborn as sns


# In[8]:


plt.figure(figsize=(10,10))
sns.heatmap(df.isnull())


# #### Observations
# Useful and product image columns have most of the missing values.
# Product meta has around 35.26 K missing values.
# Few reviewer name, review and review summary are missing. 
# However, since Review column is very important to us, the reviews which are actually null can be removed from dataset and the rest can be ignored. 

# In[9]:


df = df.dropna(axis=0, subset=['Review'])


# In[10]:


df['Review'].isnull().sum()
# No more null values in the review column


# In[11]:


df.shape


# In[12]:


from datetime import datetime


# In[13]:


df['Review_Date']=pd.to_datetime(df['Review_Date'])


# In[14]:


df['Review_Date'][0]


# In[15]:


df['Review_timestamp']=pd.to_datetime(df['Review_Date'])


# In[16]:


# Let us understand the unique value counts of few columns
columns=['Rating', 'Rev_verify','IC', 'Prod_meta','Useful']
for i in columns:
    print("The unique value counts of the column", i, "are:\n")
    print(df[i].value_counts())
    print("\n")


# In[17]:


# Countplot representation 
# Let us understand the unique value counts of few columns
columns=['Rating', 'Rev_verify']
plt.figure(figsize=(8,8))
plt.subplot(211)
print(sns.countplot(df['Rating'],hue=df['Rev_verify']))
plt.subplot(212)
print(sns.countplot(df['Rev_verify'],hue=df['Rating']))


# #### Observations from the value counts
# 
# 1. The products have received maximum positive ratings of 5 followed by ratings 4.
# 
# 2. There is no much significant difference between the no. of ratings of average 3, poor 2 and very poor 1.
# 
# 3. Approximately 665k reviews are verified and 95k reviews are not verified.
# 
# 4. There are approximately 48134 unique Item Code in the dataset.
# 
# 5. There are 26276 unique product meta in the dataset.
# 
# 6. There are 386 unique values in the useful column
# 
# 7. In non verified reviews, there are positive, negative and average reviews as well.

# #### Analysing the dataset which contains images uploaded by customers

# In[18]:


imagedf=df[df['Prod_img'].astype(str).str.contains('https')]
imagedf


# Observation
# 1. 18194 reviews have images uploaded by customers

# In[19]:


# countplot of rating in the imagedf 
sns.countplot(imagedf['Rating'])


# #### Observations from above count plot
# 
# 1. We can conclude that maximum customers who are happy with the product have uploaded image in their review, followed by 4 ratings.
# 
# 2. We can also observed that those who have given one ratings have uploaded more images than those who have given two or three ratings

# #### Analysing the useful votes of ratings by the customers

# In[20]:


# We can filter the values 'None' from the dataframe and we will have only integers left  
usefuldf=df[~df['Useful'].astype(str).str.contains('None')]


# In[21]:


# since the datatype of the column is object, we need to convert it into integer and sort them
usefuldf['Useful']=usefuldf['Useful'].str.replace(',','').astype(int)
usefuldf.sort_values(by='Useful',ascending=True,inplace=True)
usefuldf


# In[22]:


# to find out the reviews which got useful votes above 1000
votes_above1000=usefuldf[usefuldf['Useful']>1000]


# In[23]:


# Analysing by using countplot
sns.countplot(votes_above1000['Rating'])


# In[24]:


# to find out the reviews which got useful votes below 500
votes_below500=usefuldf[usefuldf['Useful']<=500]
sns.countplot(votes_below500['Rating'])


# Observation of useful votes
# 
# We can observe that above 1000 votes, the products have only higher ratings of 4 and 5 and for below 500 votes, the higher rating of 5 is most and other ratings are almost same quantity. This means that people are getting benefits from the postive reviews most and are upvoting the same. Hence, positive reviews are given more weightage by the customers

# #### Year wise review analysis
# We can make year wise product unique count and ratings review for better understanding

# In[25]:


# The reviews are available from the year 2002 to 2018. So we consider the below range
for i in range(2002,2019):
    y=df[df['Review_Date'].dt.year==i]
    print("*********",i,"************")
    print("The unique products in the year", i, "are:")
    print(y['IC'].value_counts())
    print("The count of unique products are", y['IC'].nunique())
    print("\nThe ratings are:")
    print(y['Rating'].value_counts())
    print("\n")
    print("\n")


# Observations
# 
# The unique products in the year 2002 is two and for the year 2018 it is 8902.
# In all the years, the maximum ratings have been 5 and 4.

# #### Analysis by grouping the data by ItemCode and analysing the rating using the mean (of rating)

# In[26]:


# Grouping the information by Item Code
Itemgroup=df.groupby('IC').mean()


# In[27]:


Itemgroup[(Itemgroup['Rating'] >= 1) & (Itemgroup['Rating'] < 2)].sort_values(by='Rating')
# 195 unique Items have low ratings between 1 and 2


# In[28]:


Itemgroup[(Itemgroup['Rating'] >= 2) & (Itemgroup['Rating'] < 3)].sort_values(by='Rating')
# 1765 unique Items have low ratings between 2 and 3


# In[29]:


Itemgroup[(Itemgroup['Rating'] >= 3) & (Itemgroup['Rating'] < 4)].sort_values(by='Rating')
# 12314 unique Items have average ratings between 3 and 4


# In[30]:


Itemgroup[(Itemgroup['Rating'] >= 4) & (Itemgroup['Rating'] <= 5)].sort_values(by='Rating')
# 33869 unique Items have good ratings between 4 and 5


# By grouping the item by itemcode, we have understood the exact no of products with their unique code about their average ratings from the customers.
# 
# 1. 33869 unique Items have good ratings between 4 and 5
# 
# 2. 12314 unique Items have average ratings between 3 and 4
# 
# 3. 1765 unique Items have low ratings between 2 and 3
# 
# 4. 195 unique Items have low ratings between 1 and 2

# In[31]:


sns.distplot(Itemgroup['Rating'])
# The ratings is more between 4 and 5 and very less between 1 and 2


# In[32]:


import re
import gzip
import spacy

import gensim
from gensim import corpora

import pyLDAvis
import pyLDAvis.gensim


# In[33]:


import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from string import punctuation
import string
from nltk.stem import WordNetLemmatizer, PorterStemmer
wordnet=WordNetLemmatizer()
import re
stemmer=PorterStemmer()


# In[34]:


sortd=df.groupby(by='IC',sort=True)
# Let us extract the dataframe which is grouped by Item Code (IC)


# In[35]:


sortd.first()


# In[38]:


# In order to get dataframe for the unique Item code, we need to use the Item Code separately in get_group code.
a = sortd.get_group('7532385086').sort_values(by='Review_Date')
a


# In[46]:


# In order to access every Item Code, we can extract unique IC from dataframe and save it in unique which is in array form.
# From here we can access it through normal indexing
unique=df['IC'].unique()
unique[0]


# In[47]:


# There are more than 48000 unique Item Code, so we use loop function to extract the summary of reviews
finaldict={}
for i in range(len(unique)): # This iterates through every unique Item Code
    a=sortd.get_group(unique[i]) # this creates new dataframe for unique Item Code
    globals()["subject"+str(unique[i])]=[] # creating a distinct empty list named 'subject+unique IC' by using globals variable
    ## cleaning the text
    for j in range(0, len(a['Review'])): # accessing the Review column of the dataframe of unique Item Code
        view=re.sub('[^a-zA-Z]',' ', a['Review'].iloc[j]) # cleaning the column
        view=view.lower() # converting all into lower case
        view=view.split() # splitting into separate words
        #removing punctuation and stop words and lemmatizing the remaining words
        view=[wordnet.lemmatize(word) for word in view if not word in string.punctuation if not word in stopwords.words('english')]
        globals()["subject"+str(unique[i])].append(view) # appending the empty list with the cleaned words
    
    # creating dictionary on the list of words created above
    dictionary=gensim.corpora.Dictionary(globals()["subject"+str(unique[i])])
    
    #creating bow corpus from the dictionary
    bow_corpus=[dictionary.doc2bow(doc) for doc in globals()["subject"+str(unique[i])]]
    
    # building a lda model based on dictionary and bow corpus with six topics
    lda_model=gensim.models.LdaMulticore(bow_corpus,num_topics=10,id2word=dictionary,passes=10,workers=2)
    
    # creating a empty list 'y'+unique Item Code using globals variable 
    globals()["y"+str(unique[i])]=[]
    
    # using show topics for number of topics and words
    x=lda_model.show_topics(num_topics=10,num_words=6,formatted=False)
    topics_words = [(tp[0], [wd[0] for wd in tp[1]]) for tp in x]

    #Below Code Prints Topics and Words
    print("**********************************",i,"*****************************************")
    print("The Topics and Words for Item Code", unique[i], "are: ")
    for topic,words in topics_words:
        print(str(topic)+ "::"+ str(words))
    print()

    #Below Code appends only words to the newly created list y+unique Item Code 
    list1=[] # creating a new list to append the extracted words and deriving distinct words from them
    for topic,words in topics_words:
        list1.append(words)
        
    uniquelist=list(np.unique(np.array(list1))) # converting into array and extracting unique words
    unique30=uniquelist[0:30] # restricting the words upto 30 words as project requirement
    #print(unique30)
    globals()["y"+str(unique[i])].extend(unique30) # since we need only 30 unique words to be extracted from review
    
    #Below Code Prints Only Words and save it to a dictionary for future use
    print("The Distinct List of words extracted for the product reviews are:")
    print(globals()["y"+str(unique[i])])
    #print(len(globals()["y"+str(unique[i])]))
    dict1={unique[i]:globals()["y"+str(unique[i])]}
    finaldict.update(dict1)
    #print(finaldict)
    print("\n")
    print("\n")

print(finaldict)


# In[48]:


finaldict


# In[53]:


len(finaldict)


# In[59]:


# creating a dataframe from the dictionary created above
dfdict1=pd.DataFrame({ key:[value] for key, value in finaldict.items() })
dfdict1.head()


# In[67]:


# transposing the dataframe to fit the correct form
dfdict2=dfdict1.transpose()
dfdict2.head()


# In[68]:


# resetting the index of the dataframe
dfdict2.reset_index(level=0, inplace=True)
dfdict2.head()


# In[71]:


# renaming the columns
dfdict2.rename(columns={'index':'IC',0:'Review_Keywords'},inplace=True)
dfdict2.head()


# In[72]:


# checking the shape
dfdict2.shape


# In[73]:


# saving the df to csv for safety purpose
dfdict2.to_csv("dfdict2.csv")


# In[84]:


# Extracting maximum ratings from original dataframe
maxsorted=df.groupby('IC').max()
maxsorted


# In[85]:


# reseting index of the dataframe and dropping unwanted columns
maxsorted.reset_index(level=0,inplace=True)
maxsorted.drop(['Rev_verify','Review_Date','Review','Review_timestamp'],axis=1,inplace=True)


# In[89]:


# renaming columns of the dataframe
maxsorted.rename(columns={'Rating':'Maximum_Rating'},inplace=True)
maxsorted.head()


# In[75]:


# Extracting minimum ratings from original dataframe
minsorted=df.groupby('IC').min()


# In[90]:


# resetting index, dropping unwanted columns and renaming them
minsorted.reset_index(level=0,inplace=True)
minsorted.drop(['Rev_verify','Review_Date','Review','Review_timestamp'],axis=1,inplace=True)
minsorted.rename(columns={'Rating':'Minimum_Rating'},inplace=True)
minsorted.head()


# In[77]:


# extracting mean from the original dataframe
meansorted=df.groupby('IC').mean()


# In[92]:


# resetting index, dropping unwanted columns and renaming columns
meansorted.reset_index(level=0,inplace=True)
meansorted.drop(['Rev_verify'],axis=1,inplace=True)
meansorted.rename(columns={'Rating':'Average_Rating'},inplace=True)
meansorted.head()


# In[94]:


# dropping extra index column
meansorted.drop('index',axis=1,inplace=True)
meansorted.head()


# #### Merging dataframes

# In[96]:


# merging columns to combine mean and min ratings
newdf=pd.merge(meansorted,minsorted,on='IC')
newdf.head()


# In[98]:


# merging max ratings with new df and all to final dataframe 
newdf1=pd.merge(newdf,maxsorted,on='IC')
print(newdf1.head())
finaldf=pd.merge(newdf1,dfdict2,on='IC')
finaldf.head()


# In[100]:


# renaming the column to 'Item Code'
finaldf.rename(columns={'IC':'Item_Code'},inplace=True)


# In[101]:


finaldf.head()


# In[108]:


finaldf.shape


# In[102]:


# transferring the dataframe to csv and json format
finaldf.to_csv("final_dataframe.csv")
finaldf.to_json("final_dataframe.json")


# In[103]:


#checking if json file exported is fine and it is working fine
jsondf=pd.read_json("final_dataframe.json")
jsondf.head()


# In[104]:


# saving lda model
lda_model.save('lda.model')
    


# In[107]:


# checking if the model saved works
model=lda_model.load('lda.model')

# print topics
model.show_topics()


# In[ ]:




